export const menuArray = [
    {
        name: "Pizza",
        ingredients: ["pepperoni", "mushrom", "mozarella"],
        id: 0,
        price: 14,
        emoji: "🍕"
    },
    {
        name: "Hamburger",
        ingredients: ["beef", "cheese", "lettuce"],
        price: 12,
        emoji: "🍔",
        id: 1
    },
        {
        name: "beverages",
        ingredients: ["water, pineapple essence, sugar, hibiscus"],
        price: 6,
        emoji: "🍹",
        id: 2
    }
]

export default menuArray